package domain;

/**
 * Created by camelia on 10/16/2017.
 */
public class ValidationException extends Exception {

    public ValidationException(String message) {
        super(message);
    }
}
