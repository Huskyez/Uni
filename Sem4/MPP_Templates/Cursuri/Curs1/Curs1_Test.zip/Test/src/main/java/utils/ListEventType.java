package utils;

public enum ListEventType {
    ADD, REMOVE, UPDATE
}